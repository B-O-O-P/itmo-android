package com.chizhikov.contactstest.extensions

import com.chizhikov.contactstest.contacts.Contact

fun filterContacts(list: List<Contact>, query: String): List<Contact> {
    return list.filter { contact ->
        val splittedName = contact.firstName.split(' ')
        var result = contact.proneNumber.startsWith(query)
        splittedName.forEach {
            result = result || it.startsWith(query)
        }
        return@filter result
    }
}